# Stock_Prediction
make stock prediction model using Tensorflow, Python and web crawling

#Plan 
> collect news data from web crawling and extract core word using Morphological classifier
> get all stock data(Open,High,Low,Volume,Close) of company and store in database
> make RNN model using stock data and core word 

# accuracy of RNN model for predicting stock (model by 'TSLA' data and test alphabet company)
![alt text](https://github.com/SongChiyoon/Stock_Prediction/blob/master/stock_prediction.jpeg)
